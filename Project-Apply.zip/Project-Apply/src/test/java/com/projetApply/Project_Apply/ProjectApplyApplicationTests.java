package com.projetApply.Project_Apply;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectApplyApplicationTests {

	@Test
	void contextLoads() {
	}

}
