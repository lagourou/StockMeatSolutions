package com.projetApply.Project_Apply.model;

public enum PaymentType {

    CARD,
    CASH

}
