package com.projetApply.Project_Apply;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectApplyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectApplyApplication.class, args);
	}

}
